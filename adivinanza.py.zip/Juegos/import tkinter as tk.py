import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random
import pygame
import os

# Inicializar pygame para el sonido
pygame.mixer.init()

# Directorios de imágenes y sonidos
IMG_DIR = "imagenes"
CORRECT_IMAGE = os.path.join(IMG_DIR, "acierto.png")
WRONG_IMAGE = os.path.join(IMG_DIR, "fallo.png")
MUSIC_DIR = "musica"
CORRECT_MUSIC_DIR = os.path.join(MUSIC_DIR, "correcto")
WRONG_MUSIC_DIR = os.path.join(MUSIC_DIR, "incorrecto")

# Rango de dificultad
RANGOS = {
    "facil": 10,
    "medio": 50,
    "dificil": 100
}

# Función para elegir aleatoriamente un sonido
def elegir_sonido(directorio):
    if os.path.exists(directorio):
        archivos = [f for f in os.listdir(directorio) if f.endswith(".wav")]
        return os.path.join(directorio, random.choice(archivos)) if archivos else None
    return None

# Función para generar preguntas con variación
def generar_pregunta(numero, dificultad):
    preguntas_base = [
        f"¿Cuál es el número secreto entre 0 y {RANGOS[dificultad]}?",
        f"Estoy pensando en un número del 0 al {RANGOS[dificultad]}, ¿puedes adivinarlo?",
        f"Piensa en un número entre 0 y {RANGOS[dificultad]}."
    ]
    
    pistas = {
        "facil": [
            f"El número es {'par' if numero % 2 == 0 else 'impar'}.",
            f"El número está entre {max(0, numero-3)} y {min(RANGOS[dificultad], numero+3)}."
        ],
        "medio": [
            f"El número es mayor que {max(0, numero - random.randint(1, 10))}.",
            f"El número es menor que {min(RANGOS[dificultad], numero + random.randint(1, 10))}."
        ],
        "dificil": [
            "No hay pistas esta vez, ¡suerte!",
            "Piensa con lógica y estrategia."
        ]
    }
    return random.choice(preguntas_base) + " " + random.choice(pistas[dificultad])

RESPUESTAS_CORRECTAS = [
    "¡Bien hecho! ¡Adivinaste!", 
    "¡Increíble, acertaste!",
    "¡Lo lograste! ¡Sigue así!"
]
RESPUESTAS_INCORRECTAS = {
    "facil": ["Casi, sigue intentando.", "No es correcto, pero estás cerca."],
    "medio": ["No es el número, intenta de nuevo.", "Piensa bien, estás en el camino."],
    "dificil": ["Incorrecto, pero no te rindas.", "No es fácil, sigue intentando."]
}

class AdivinanzaNumero:
    def __init__(self, root):
        self.root = root
        self.root.title("Juego de Adivinanza de Números")
        self.root.geometry("500x500")
        
        self.numero_secreto = None
        self.dificultad = "facil"
        
        self.label_dificultad = tk.Label(root, text="Selecciona dificultad:")
        self.label_dificultad.pack()
        
        self.dificultad_var = tk.StringVar(value="facil")
        self.menu_dificultad = tk.OptionMenu(root, self.dificultad_var, *RANGOS.keys())
        self.menu_dificultad.pack()
        self.dificultad_var.trace_add("write", self.cambiar_dificultad)
        
        self.imagen_label = tk.Label(root)
        self.imagen_label.pack()
        
        self.label_pregunta = tk.Label(root, text="", font=("Arial", 12), wraplength=400)
        self.label_pregunta.pack(pady=10)
        
        self.entry_respuesta = tk.Entry(root)
        self.entry_respuesta.pack(pady=5)
        
        self.boton_comprobar = tk.Button(root, text="Comprobar", command=self.comprobar_respuesta)
        self.boton_comprobar.pack(pady=5)
        
        self.boton_iniciar = tk.Button(root, text="Iniciar Nueva Partida", command=self.nueva_partida)
        self.boton_iniciar.pack(pady=5)
        
        self.boton_salir = tk.Button(root, text="Salir", command=root.quit)
        self.boton_salir.pack(pady=5)
        
        self.label_resultado = tk.Label(root, text="", font=("Arial", 12))
        self.label_resultado.pack(pady=10)
        
        self.nueva_partida()
        
    def cambiar_dificultad(self, *_):
        self.dificultad = self.dificultad_var.get()
        self.nueva_partida()
        
    def nueva_partida(self):
        self.numero_secreto = random.randint(0, RANGOS[self.dificultad])
        self.label_pregunta.config(text=generar_pregunta(self.numero_secreto, self.dificultad))
        self.entry_respuesta.delete(0, tk.END)
        self.label_resultado.config(text="")
        self.mostrar_imagen(None)
        
    def mostrar_imagen(self, tipo):
        imagen_path = CORRECT_IMAGE if tipo == "correcto" else WRONG_IMAGE if tipo == "incorrecto" else None
        
        if imagen_path and os.path.exists(imagen_path):
            imagen = Image.open(imagen_path)
            imagen = imagen.resize((100, 100))
            self.img = ImageTk.PhotoImage(imagen)
            self.imagen_label.config(image=self.img)
        else:
            self.imagen_label.config(image="")

    def comprobar_respuesta(self):
        try:
            respuesta = int(self.entry_respuesta.get())
        except ValueError:
            messagebox.showwarning("Entrada inválida", "Por favor, ingresa un número válido.")
            return
        
        if respuesta == self.numero_secreto:
            self.label_resultado.config(text=random.choice(RESPUESTAS_CORRECTAS), fg="green")
            self.mostrar_imagen("correcto")
            sonido = elegir_sonido(CORRECT_MUSIC_DIR)
            if sonido:
                pygame.mixer.Sound(sonido).play()
            messagebox.showinfo("¡Correcto!", random.choice(RESPUESTAS_CORRECTAS))
            self.nueva_partida()
        else:
            mensaje_incorrecto = random.choice(RESPUESTAS_INCORRECTAS[self.dificultad])
            self.label_resultado.config(text=mensaje_incorrecto, fg="red")
            self.mostrar_imagen("incorrecto")
            sonido = elegir_sonido(WRONG_MUSIC_DIR)
            if sonido:
                pygame.mixer.Sound(sonido).play()
            messagebox.showwarning("Incorrecto", mensaje_incorrecto)
            self.entry_respuesta.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = AdivinanzaNumero(root)
    root.mainloop()
